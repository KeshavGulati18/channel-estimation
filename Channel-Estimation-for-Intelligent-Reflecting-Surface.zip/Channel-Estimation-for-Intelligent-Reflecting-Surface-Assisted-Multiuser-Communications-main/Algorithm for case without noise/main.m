%% ======================================================
% This file is the channel estimation algorithm WITHOUT noise shown in Section IV 
% of the paper "Channel Estimation for Intelligent Reflecting Surface Assisted Multiuser Communications: Framework, 
% Algorithms, and Analysis" by Zhaorui Wang, Liang Liu, and Shuguang Cui.
% Channel Model: Correlated Racian Fading. It can be replaced by others as long as the channels are linearly independent
%% ========================================================
clc
clear
M=32; % number of receive antennas
K=8; % number of users
N=32; % number of IRS elements
T0=K; % minimum number of training symbols in the first stage
T1=N; % minimum number of training symbols in the second stage
if M>=N
    T2=K-1; % minimum number of training symbols in the third stage
else
    T2=ceil(N*(K-1)/M); % minimum number of training symbols in the third stage
end
T=T0+T1+T2;
%% channel parameters
d0=0.01;
d_bs=d0*100^(-2.2); % pathloss between IRS and BS
d_ue=d0*(10*rand(K,1)+5).^(-2.1); % pathloss  between IRS and users
d_drl=d0*(10*rand(K,1)+100).^(-4.2); % pathloss of direct channels
c_irs=0.3+0.4*1j; % channel correlation
c_bs=0.5+0.3*1j;  % channel correlation
C_irs=C_gen(N,c_irs); % generate correlation matrix. Please refer to the file 'algorithm for the case with noise' for C_irss are different among different users. 
C_bs=C_gen(M,c_bs); % generate of correlation matrix Please refer to the file 'algorithm for the case with noise' for C_bss are different among different users. 
SNR=10000; % i.e., no noise. 
%% ===============Phase I===========================
F0_temp=dftmtx(T0);
A0=F0_temp(1:K,:); % pilot matrix

H_drl_mtx=[];
for i_h=1:K
   % Generate direct channel matrix for each user. The matrix is formed by
   % multiplying a complex Gaussian random vector (scaled by sqrt(d_drl(i_h)))
   % with the square root of the receive antenna correlation matrix (C_bs).
   H_drl_temp=sqrtm(C_bs)*1/sqrt(2)*(randn(M,1)+1j*randn(M,1))*sqrt(d_drl(i_h));
   H_drl_mtx=[H_drl_mtx H_drl_temp];
end

% Transmit pilot symbols through direct channels (Phase I) and calculate the
% estimated direct channel matrix H_drl_mtx_es using the received signal.
Y0=H_drl_mtx*A0;
H_drl_mtx_es=Y0*A0'/T0;

%% Phase II: Channel Estimation for IRS Coefficients
P1_bit=1; % Number of bits per pilot symbol (assumed to be 1 in this case).
F1=dftmtx(T1);
Phi1=F1(1:N,:); % IRS reflection matrix for Phase II (none normalized DFT matrix).

a1=diag(ones(T1,1))*sqrt(P1_bit); % Pilot symbols for Phase II, a=diag(1,1,...,1)*sqrt(P1/N).

% Generate the base station and user channel matrices (H_bs and H_ue1) for the
% first user and combine them to form the overall channel matrix H1_mtx.
H_bs_hat=1/sqrt(2)*(randn(M,N)+1j*randn(M,N));
H_bs=sqrt(d_bs)*sqrtm(C_bs)*H_bs_hat*sqrtm(C_irs);
H_ue1_hat=1/sqrt(2)*(randn(N,1)+1j*randn(N,1));
H_ue1=sqrt(d_ue(1))*sqrtm(C_irs)*H_ue1_hat;
H1_mtx=H_bs*diag(H_ue1);

a1_drl=ones(1,T1); % Pilot symbols for direct channel estimation in Phase II.

% Transmit pilot symbols through the composite channel (BS-IRS-user1 direct
% path + IRS reflected paths) and calculate the received signal Y1.
Y1=H1_mtx*Phi1*a1+H_drl_mtx(:,1)*a1_drl; 
Y1=Y1-H_drl_mtx_es(:,1)*a1_drl;

% Estimate the composite channel matrix H1_mtx_es using the received signal Y1.
H1_mtx_es=Y1*Phi1'/T1;

%% Phase III: Channel Estimation for Reflecting Coefficients of Users 2 to K
coeff=zeros(N,K); % Initializing the matrix to store the user coefficients.
for k=2:K
   % Generating channels from user 2 to K.
   H_uek_hat=1/sqrt(2)*(randn(N,1)+1j*randn(N,1));
   H_uek=sqrt(d_ue(k))*sqrtm(C_irs)*H_uek_hat;
   coeff(:,k)=H_uek./H_ue1; % Calculate the coefficients for each user relative to user 1.
end

% Channel estimation for IRS coefficients (reflecting coefficients).
% If M >= N, use the 'coeffes2_MgeN' function for estimation, otherwise use
% 'coeffes2_MlN' function.
if M >= N
  coeff_es=coeffes2_MgeN(H1_mtx_es,K,coeff,H1_mtx,H_drl_mtx_es,H_drl_mtx);
else
  coeff_es=coeffes2_MlN(M,H1_mtx_es,N,K,coeff,H1_mtx,H_drl_mtx_es,H_drl_mtx);
end

coeff_es(:,1)=[]; % Remove the estimated coefficients for user 1.
coeff(:,1)=[];   % Remove the true coefficients for user 1.

% The channel estimation is now complete, and the 'coeff' and 'coeff_es'
% matrices contain the true and estimated coefficients, respectively, for
% users 2 to K.

% The normalized MSE can be computed using these coefficients to assess the
% performance of the channel estimation algorithm.


coeff_es=reshape(coeff_es,(K-1)*N,1); % Reshape the estimated coefficients matrix into a vector.
coeff=reshape(coeff,(K-1)*N,1); % Reshape the true coefficients matrix into a vector.

H_drl_es=reshape(H_drl_mtx_es,M*K,1); % Reshape the estimated direct channel matrix into a vector.
H_drl=reshape(H_drl_mtx,M*K,1); % Reshape the true direct channel matrix into a vector.

H1_es=reshape(H1_mtx_es,M*N,1); % Reshape the estimated composite channel matrix into a vector.
H1=reshape(H1_mtx,M*N,1); % Reshape the true composite channel matrix into a vector.

H_es=[H_drl_es;H1_es]; % Concatenate the estimated direct and composite channel vectors.
H_real=[H_drl;H1]; % Concatenate the true direct and composite channel vectors.

% Loop over each user (except user 1) to compute the estimated and true
% composite channel vectors, using the estimated and true coefficients.
for iii=1:K-1
  H_es_temp=H1_mtx_es*diag(coeff_es((iii-1)*N+1:iii*N));
  H_real_temp=H1_mtx*diag(coeff((iii-1)*N+1:iii*N));
  H_es_temp2=reshape(H_es_temp,N*M,1); % Reshape the estimated composite channel matrix into a vector.
  H_real_temp2=reshape(H_real_temp,N*M,1); % Reshape the true composite channel matrix into a vector.
  H_es=[H_es;H_es_temp2]; % Concatenate the estimated composite channel vectors.
  H_real=[H_real;H_real_temp2]; % Concatenate the true composite channel vectors.
end  

p_s=H_real'*H_real; % Total channel power approximation (inner product of true channel vector).
MSE=(H_es-H_real)'*(H_es-H_real)/p_s; % Compute the normalized mean square error (MSE).

fprintf('Normalized Mean Square Error: '); disp(MSE); % Display the MSE value.

% Check if the MSE is less than 10^(-10), indicating perfect channel estimation.
if MSE<10^(-10)
   fprintf('Perfect Channel Estimation');
end
